﻿using Lesson09.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Linq;

namespace Lesson09.Controllers
{
    public class RPNotesController : Controller
    {
        private AppDbContext _dbContext;

        public RPNotesController(AppDbContext dbContext)
        {
            _dbContext = dbContext;
        }

        public IActionResult Index()
        {
            DbSet<Module> dbs = _dbContext.Module;
            var model = dbs.Include(m => m.Lesson)
                            .ToList();

            return View(model);
        }

        [HttpPost]
        public IActionResult SaveNotes(Lesson ulesson)
        {
            if (ModelState.IsValid)
            {
                DbSet<Lesson> dbs = _dbContext.Lesson;
                var tLesson = dbs.Where(l => l.ModuleId == ulesson.ModuleId
                                    && l.LessonId == ulesson.LessonId)
                                .FirstOrDefault();
                if (tLesson != null)
                {
                    tLesson.Notes = ulesson.Notes == null ? "" : ulesson.Notes;
                    if (_dbContext.SaveChanges() == 1)
                        TempData["Msg"] = "Notes saved!";
                    else
                        TempData["Msg"] = "Failed to save notes!";
                }
                else
                    TempData["Msg"] = "Notes not found!";
            }
            else
                TempData["Msg"] = "Invalid data entry!";
            return RedirectToAction("Index");
        }

        // TODO Lesson09 Solution Task: Complete the GetModules to return partial view _ModulesNav with correct model.
        public IActionResult GetModules()
        {
            DbSet<Module> dbs = _dbContext.Module;

            return Ok(1);
        }
    }
}
//19023542 Zulfaqar